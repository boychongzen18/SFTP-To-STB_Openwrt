<?php
    include('auth.php');
    check_session();
?>
<!doctype html>
<html lang="en">
<head>
    <?php
        $title = "LuCi";
        include("head.php");
    ?>
</head>
<style>
    #sc-container {
        margin: 0 auto;
    }
</style>
<body>
<div id="app">
    <?php include('navbar.php'); ?>
                <div class="embed-responsive embed-responsive-1by1">
                            <iframe class="embed-responsive-item" src="http://192.168.1.1" target="_blank" allowfullscreen></iframe>
                </div>
            </div>
        </div>
        <?php include('footer.php'); ?>
    </div>
</div>
<?php include("javascript.php"); ?>
</body>
</html>