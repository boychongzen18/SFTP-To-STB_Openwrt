<?php
    include('auth.php');
    check_session();
?>
<!doctype html>
<html lang="en">
<head>
    <?php
        $title = "Restart";
        include("head.php");
    ?>
</head>
<body>
<div id="app">
<?php
    if (isset($_POST['button']))
    {
         exec('reboot');
    }
?>
<?php include('navbar.php'); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-12 mx-auto mt-4 mb-2">
                <div class="card">
                    <div class="card-header">
                        <div class="text-center">
                            <h3><i class="fa fa-recycle"></i> Restart</h3>
                        </div>
                    </div>
							<div class="card-body">
							 
								<div class="text-center">
								<p>Proses Restart system membutuhka waktu 1 Menit </p>
									<div>
										<form method="post">
											<p>
											<button onclick="konfirmasi()" class="btn btn-primary" name="button"> <i class="fa fa-recycle"></i> Restart</button>
											<p id="pesan"></p>
											</p>
											<script>
												function konfirmasi(){
												var tanya = confirm("Apakah Anda Akan Me-restart Perangkat Ini ?");
												if(tanya === true) {
												pesan = "Ya";
												}else{
												pesan = "Tidak";
												}
												document.getElementById("pesan").innerHTML = pesan;
												}
											</script>
										</form>
									</div>
								</div>
							</div>
					</div>
                </div>
            </div>
        </div>
        <?php include('footer.php'); ?>
    </div>
</div>
<?php include("javascript.php"); ?>
<script src="js/about.js"></script>
</body>
</html>

